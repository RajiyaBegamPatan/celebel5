import pandas as pd
import sqlite3
import schedule
import time
from fastavro import writer, parse_schema
from sqlalchemy import create_engine, inspect

# Step 1: Connect to database
engine = create_engine("sqlite:///sample.db")

# Step 2: Function to export all tables
def export_all_tables():
    inspector = inspect(engine)
    tables = inspector.get_table_names()

    for table in tables:
        df = pd.read_sql(f"SELECT * FROM {table}", engine)

        # Save as CSV
        df.to_csv(f"{table}.csv", index=False)

        # Save as Parquet
        df.to_parquet(f"{table}.parquet", engine="pyarrow", index=False)

        # Save as Avro
        schema = {
            "doc": f"{table} data",
            "name": table,
            "namespace": "example.avro",
            "type": "record",
            "fields": [{"name": col, "type": "string"} for col in df.columns]
        }
        records = df.astype(str).to_dict(orient="records")
        with open(f"{table}.avro", "wb") as out:
            writer(out, parse_schema(schema), records)

        print(f"✅ Exported {table} to CSV, Parquet, Avro")

# Step 3: Run immediately
export_all_tables()

# Step 4: Automate - run every hour
schedule.every(1).hours.do(export_all_tables)

while True:
    schedule.run_pending()
    time.sleep(1)